<?php
/**
 * Plugin Name: DiplomaOne Fixes
 * Description: Auto-complete virtual orders, disable guest checkout, redirect to Paper Solutions after purchase.
 * Version: 2.0
 */

// 1. Force disable guest checkout
add_filter('pre_option_woocommerce_enable_guest_checkout', function() { return 'no'; });
add_filter('woocommerce_checkout_registration_required', '__return_true');

// 2. Auto-complete all virtual orders after payment
add_filter('woocommerce_payment_complete_order_status', function($status, $order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return $status;
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        if ($product && !$product->is_virtual()) return $status;
    }
    return 'completed';
}, 10, 2);

add_action('woocommerce_thankyou', function($order_id) {
    if (!$order_id) return;
    $order = wc_get_order($order_id);
    if (!$order) return;
    if ($order->get_status() === 'processing') {
        $all_virtual = true;
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product && !$product->is_virtual()) { $all_virtual = false; break; }
        }
        if ($all_virtual) {
            $order->update_status('completed', 'Auto-completed (paper purchase).');
        }
    }
    // 3. Redirect back to Paper Solutions after 2 seconds
    ?>
    <script>
    setTimeout(function(){ window.location.href = '/paper-solutions/'; }, 2000);
    </script>
    <?php
});
