<?php
/**
 * Plugin Name: DiplomaOne Fixes
 * Description: Auto-complete paper orders, output REST nonce for Paper Solutions access check, redirect after payment.
 * Version: 3.0
 */

// ===== 1. AUTO-COMPLETE VIRTUAL ORDERS AFTER PAYMENT (MULTIPLE HOOKS FOR RELIABILITY) =====

add_filter('woocommerce_payment_complete_order_status', 'd1_auto_complete_virtual', 99, 2);
function d1_auto_complete_virtual($status, $order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return $status;
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        if ($product && !$product->is_virtual()) return $status;
    }
    return 'completed';
}

// Also catch orders that go to processing and auto-complete them
add_action('woocommerce_order_status_processing', 'd1_complete_processing_virtual');
function d1_complete_processing_virtual($order_id) {
    $order = wc_get_order($order_id);
    if (!$order) return;
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        if ($product && !$product->is_virtual()) return;
    }
    $order->update_status('completed', 'Auto-completed virtual paper order.');
}

// Backup: on thank-you page, ensure virtual orders are completed
add_action('woocommerce_thankyou', 'd1_complete_on_thankyou');
function d1_complete_on_thankyou($order_id) {
    if (!$order_id) return;
    $order = wc_get_order($order_id);
    if (!$order) return;
    if ($order->get_status() !== 'completed') {
        $all_virtual = true;
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product && !$product->is_virtual()) { $all_virtual = false; break; }
        }
        if ($all_virtual) {
            $order->update_status('completed', 'Auto-completed paper order (thank-you page).');
        }
    }
}

// ===== 2. OUTPUT REST NONCE ON PAPER SOLUTIONS PAGE SO ACCESS CHECK WORKS =====

add_action('wp_footer', 'd1_output_access_config');
function d1_output_access_config() {
    if (is_page('paper-solutions')) {
        $nonce = wp_create_nonce('wp_rest');
        $rest_url = get_rest_url();
        echo "<script>window.DiplomaOneAccess = { nonce: " . json_encode($nonce) . ", rest: " . json_encode($rest_url) . " };</script>";
    }
}

// ===== 3. REDIRECT BACK TO PAPER SOLUTIONS AFTER PAYMENT =====

add_action('woocommerce_thankyou', 'd1_redirect_to_papers');
function d1_redirect_to_papers($order_id) {
    ?>
    <script>
    setTimeout(function(){ window.location.href = '/paper-solutions/?purchased=1'; }, 2000);
    </script>
    <?php
}
